package com.example;

/**
 * A simple calculator class — used as a target for UNIT TESTS.
 * Each method is pure (no I/O, no dependencies), making it ideal for isolated testing.
 */
public class Calculator {

    public int add(int a, int b) {
        return a + b;
    }

    public int subtract(int a, int b) {
        return a - b;
    }

    public int multiply(int a, int b) {
        return a * b;
    }

    /**
     * Divides a by b.
     * @throws ArithmeticException when b is zero.
     */
    public double divide(int a, int b) {
        if (b == 0) {
            throw new ArithmeticException("Cannot divide by zero");
        }
        return (double) a / b;
    }

    public boolean isEven(int n) {
        return n % 2 == 0;
    }
}
