package com.example;

import java.util.*;

/**
 * Repository abstraction for users. In a real app this would talk to a database.
 * For integration tests we either use the in-memory impl below, or mock this interface.
 */
public interface UserRepository {
    void save(User user);
    Optional<User> findById(int id);
    List<User> findAll();
    boolean delete(int id);

    /** Simple in-memory implementation used by integration tests. */
    class InMemoryUserRepository implements UserRepository {
        private final Map<Integer, User> store = new HashMap<>();

        @Override public void save(User user) {
            store.put(user.getId(), user);
        }

        @Override public Optional<User> findById(int id) {
            return Optional.ofNullable(store.get(id));
        }

        @Override public List<User> findAll() {
            return new ArrayList<>(store.values());
        }

        @Override public boolean delete(int id) {
            return store.remove(id) != null;
        }
    }
}
