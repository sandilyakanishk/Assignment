package com.example;

import java.util.Objects;

/** Simple domain model used by UserService. */
public class User {
    private final int id;
    private final String name;
    private final String email;

    public User(int id, String name, String email) {
        this.id = id;
        this.name = name;
        this.email = email;
    }

    public int getId()       { return id; }
    public String getName()  { return name; }
    public String getEmail() { return email; }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof User other)) return false;
        return id == other.id
                && Objects.equals(name, other.name)
                && Objects.equals(email, other.email);
    }

    @Override
    public int hashCode() { return Objects.hash(id, name, email); }

    @Override
    public String toString() {
        return "User{id=" + id + ", name='" + name + "', email='" + email + "'}";
    }
}
