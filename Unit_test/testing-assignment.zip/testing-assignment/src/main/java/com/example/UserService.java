package com.example;

import java.util.List;

/**
 * Business-logic layer. Sits on top of UserRepository.
 *
 * Integration tests will exercise UserService TOGETHER WITH a real repository,
 * verifying that the two collaborate correctly (vs. a unit test which would mock the repo).
 */
public class UserService {

    private final UserRepository repository;

    public UserService(UserRepository repository) {
        this.repository = repository;
    }

    public void register(User user) {
        if (user.getEmail() == null || !user.getEmail().contains("@")) {
            throw new IllegalArgumentException("Invalid email: " + user.getEmail());
        }
        if (repository.findById(user.getId()).isPresent()) {
            throw new IllegalStateException("User with id " + user.getId() + " already exists");
        }
        repository.save(user);
    }

    public User getById(int id) {
        return repository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("User not found: " + id));
    }

    public List<User> listAll() {
        return repository.findAll();
    }

    public boolean removeUser(int id) {
        return repository.delete(id);
    }
}
