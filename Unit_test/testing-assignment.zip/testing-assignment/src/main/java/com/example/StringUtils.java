package com.example;

/**
 * Static-style utility class for string operations. Second target for unit tests.
 */
public class StringUtils {

    public String reverse(String s) {
        if (s == null) {
            throw new IllegalArgumentException("Input string cannot be null");
        }
        return new StringBuilder(s).reverse().toString();
    }

    public boolean isPalindrome(String s) {
        if (s == null) return false;
        String cleaned = s.toLowerCase().replaceAll("[^a-z0-9]", "");
        return cleaned.equals(reverse(cleaned));
    }

    public int countVowels(String s) {
        if (s == null) return 0;
        int count = 0;
        for (char c : s.toLowerCase().toCharArray()) {
            if ("aeiou".indexOf(c) >= 0) count++;
        }
        return count;
    }
}
