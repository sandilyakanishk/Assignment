package com.example.unit;

import com.example.StringUtils;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("StringUtils — Unit Tests (JUnit 5)")
class StringUtilsTest {

    private final StringUtils utils = new StringUtils();

    @Test
    @DisplayName("reverse() reverses a normal string")
    void reverseNormalString() {
        assertEquals("olleh", utils.reverse("hello"));
    }

    @Test
    @DisplayName("reverse() returns empty string for empty input")
    void reverseEmptyString() {
        assertEquals("", utils.reverse(""));
    }

    @Test
    @DisplayName("reverse() throws on null input")
    void reverseNullThrows() {
        assertThrows(IllegalArgumentException.class, () -> utils.reverse(null));
    }

    @ParameterizedTest(name = "\"{0}\" is a palindrome")
    @ValueSource(strings = {"madam", "racecar", "A man a plan a canal Panama", "12321"})
    void detectsPalindromes(String input) {
        assertTrue(utils.isPalindrome(input));
    }

    @ParameterizedTest(name = "\"{0}\" is NOT a palindrome")
    @ValueSource(strings = {"hello", "world", "java"})
    void detectsNonPalindromes(String input) {
        assertFalse(utils.isPalindrome(input));
    }

    @Test
    @DisplayName("countVowels() counts a, e, i, o, u (case-insensitive)")
    void countVowels() {
        assertEquals(5, utils.countVowels("Education"));
        assertEquals(0, utils.countVowels("rhythm"));
        assertEquals(0, utils.countVowels(""));
    }
}
