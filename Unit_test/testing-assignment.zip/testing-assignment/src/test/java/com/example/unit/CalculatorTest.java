package com.example.unit;

import com.example.Calculator;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.*;

/**
 * UNIT TESTS for Calculator using JUnit 5 (Jupiter).
 *
 * Characteristics of a good unit test:
 *  - Tests ONE class in isolation
 *  - No external dependencies (no DB, network, files)
 *  - Fast (milliseconds)
 *  - Deterministic
 */
@DisplayName("Calculator — Unit Tests (JUnit 5)")
class CalculatorTest {

    private Calculator calculator;

    @BeforeEach
    void setUp() {
        // Fresh instance before each test — keeps tests independent.
        calculator = new Calculator();
    }

    @Test
    @DisplayName("add() returns the sum of two positive integers")
    void addPositiveNumbers() {
        assertEquals(7, calculator.add(3, 4));
    }

    @Test
    @DisplayName("add() handles negative numbers")
    void addNegativeNumbers() {
        assertEquals(-1, calculator.add(2, -3));
    }

    @Test
    @DisplayName("subtract() returns the difference")
    void subtract() {
        assertEquals(5, calculator.subtract(10, 5));
    }

    @Test
    @DisplayName("multiply() returns the product")
    void multiply() {
        assertEquals(20, calculator.multiply(4, 5));
    }

    @Test
    @DisplayName("divide() returns the quotient as a double")
    void divide() {
        assertEquals(2.5, calculator.divide(5, 2), 0.0001);
    }

    @Test
    @DisplayName("divide() by zero throws ArithmeticException")
    void divideByZeroThrows() {
        ArithmeticException ex = assertThrows(
                ArithmeticException.class,
                () -> calculator.divide(10, 0)
        );
        assertEquals("Cannot divide by zero", ex.getMessage());
    }

    /**
     * Parameterized test — JUnit 5 runs this once per row.
     * Demonstrates data-driven testing without writing six near-identical tests.
     */
    @ParameterizedTest(name = "isEven({0}) → {1}")
    @CsvSource({
            "0,  true",
            "2,  true",
            "4,  true",
            "1,  false",
            "7,  false",
            "-3, false"
    })
    @DisplayName("isEven() returns true for even numbers, false otherwise")
    void isEven(int input, boolean expected) {
        assertEquals(expected, calculator.isEven(input));
    }
}
