package com.example.e2e;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.junit.jupiter.api.*;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.*;

/**
 * END-TO-END (E2E) TESTS using Selenium WebDriver.
 *
 * What makes this E2E:
 *  - We drive a REAL browser (headless Chrome)
 *  - We test a complete user journey: open page → fill form → click button → verify result
 *  - Nothing about the application internals is mocked
 *
 * Target: https://the-internet.herokuapp.com — a public site explicitly maintained
 * for Selenium practice, so this test will work out of the box.
 *
 * Filename ends with "E2ETest" → picked up by Maven Failsafe (integration phase).
 *
 * Prerequisite: Chrome (or Chromium) installed on the machine. WebDriverManager
 * automatically downloads the matching chromedriver, so no manual driver setup needed.
 */
@DisplayName("Login flow — End-to-End Tests (Selenium)")
class LoginE2ETest {

    private static final String LOGIN_URL = "https://the-internet.herokuapp.com/login";

    // Valid credentials documented by the practice site.
    private static final String VALID_USER = "tomsmith";
    private static final String VALID_PASS = "SuperSecretPassword!";

    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeAll
    static void setupDriverBinary() {
        // Downloads & caches the correct chromedriver for the installed Chrome version.
        WebDriverManager.chromedriver().setup();
    }

    @BeforeEach
    void launchBrowser() {
        ChromeOptions options = new ChromeOptions();
        // Headless = no visible window. Required in CI; comment out to watch tests run.
        options.addArguments("--headless=new");
        options.addArguments("--no-sandbox");
        options.addArguments("--disable-dev-shm-usage");
        options.addArguments("--window-size=1280,800");

        driver = new ChromeDriver(options);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    @AfterEach
    void closeBrowser() {
        if (driver != null) driver.quit();
    }

    @Test
    @DisplayName("Successful login redirects to /secure and shows the success banner")
    void successfulLogin() {
        driver.get(LOGIN_URL);

        driver.findElement(By.id("username")).sendKeys(VALID_USER);
        driver.findElement(By.id("password")).sendKeys(VALID_PASS);
        driver.findElement(By.cssSelector("button[type='submit']")).click();

        // Wait for the success page
        wait.until(ExpectedConditions.urlContains("/secure"));

        WebElement flash = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.id("flash"))
        );
        assertTrue(flash.getText().contains("You logged into a secure area"),
                "Expected success banner after login");
        assertTrue(driver.getCurrentUrl().endsWith("/secure"),
                "URL should be /secure after successful login");
    }

    @Test
    @DisplayName("Invalid username shows the correct error banner")
    void loginWithInvalidUsername() {
        driver.get(LOGIN_URL);

        driver.findElement(By.id("username")).sendKeys("wrongUser");
        driver.findElement(By.id("password")).sendKeys(VALID_PASS);
        driver.findElement(By.cssSelector("button[type='submit']")).click();

        WebElement flash = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.id("flash"))
        );
        assertTrue(flash.getText().contains("Your username is invalid"),
                "Expected username-error banner");
        // Should still be on /login
        assertTrue(driver.getCurrentUrl().endsWith("/login"));
    }

    @Test
    @DisplayName("Invalid password shows the correct error banner")
    void loginWithInvalidPassword() {
        driver.get(LOGIN_URL);

        driver.findElement(By.id("username")).sendKeys(VALID_USER);
        driver.findElement(By.id("password")).sendKeys("wrongPassword");
        driver.findElement(By.cssSelector("button[type='submit']")).click();

        WebElement flash = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.id("flash"))
        );
        assertTrue(flash.getText().contains("Your password is invalid"),
                "Expected password-error banner");
    }

    @Test
    @DisplayName("Logout from secure area returns to /login with a confirmation banner")
    void logoutAfterLogin() {
        // First log in
        driver.get(LOGIN_URL);
        driver.findElement(By.id("username")).sendKeys(VALID_USER);
        driver.findElement(By.id("password")).sendKeys(VALID_PASS);
        driver.findElement(By.cssSelector("button[type='submit']")).click();
        wait.until(ExpectedConditions.urlContains("/secure"));

        // Then click logout
        driver.findElement(By.cssSelector("a[href='/logout']")).click();
        wait.until(ExpectedConditions.urlContains("/login"));

        WebElement flash = wait.until(
                ExpectedConditions.visibilityOfElementLocated(By.id("flash"))
        );
        assertTrue(flash.getText().contains("You logged out"),
                "Expected logout confirmation banner");
    }
}
