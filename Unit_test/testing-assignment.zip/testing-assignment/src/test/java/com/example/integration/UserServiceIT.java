package com.example.integration;

import com.example.User;
import com.example.UserRepository;
import com.example.UserService;
import org.testng.annotations.*;

import java.util.List;

import static org.testng.Assert.*;

/**
 * INTEGRATION TESTS using TestNG.
 *
 * Key distinction from unit tests:
 *  - We DO NOT mock UserRepository. We use the REAL InMemoryUserRepository.
 *  - We are verifying that UserService and UserRepository work CORRECTLY TOGETHER.
 *  - In a real app this would integrate against a real (or in-memory) database.
 *
 * Filename ends with "IT" → picked up by the Maven Failsafe plugin (integration phase),
 * not by Surefire (unit phase).
 */
public class UserServiceIT {

    private UserService service;
    private UserRepository repository;

    @BeforeMethod
    public void setUp() {
        // Real repository — that's what makes this an INTEGRATION test.
        repository = new UserRepository.InMemoryUserRepository();
        service = new UserService(repository);
    }

    @Test(description = "Registering a valid user persists it via the repository")
    public void registerUser_persistsToRepository() {
        User user = new User(1, "Alice", "alice@example.com");

        service.register(user);

        // Verify the user was actually saved by querying the repo directly.
        assertTrue(repository.findById(1).isPresent(),
                "Repository should contain the registered user");
        assertEquals(repository.findById(1).get(), user);
    }

    @Test(description = "Registering a user with invalid email throws")
    public void registerUser_withInvalidEmail_throws() {
        User bad = new User(2, "Bob", "not-an-email");

        assertThrows(IllegalArgumentException.class, () -> service.register(bad));
        assertTrue(repository.findAll().isEmpty(),
                "Repository should remain empty after a failed register");
    }

    @Test(description = "Registering a duplicate id is rejected")
    public void registerUser_duplicateId_throws() {
        service.register(new User(1, "Alice", "alice@example.com"));

        assertThrows(IllegalStateException.class,
                () -> service.register(new User(1, "Other", "other@example.com")));
    }

    @Test(description = "getById returns the saved user")
    public void getById_returnsSavedUser() {
        User u = new User(42, "Carol", "carol@example.com");
        service.register(u);

        User found = service.getById(42);
        assertEquals(found, u);
    }

    @Test(description = "getById throws when user is missing")
    public void getById_missingUser_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.getById(999));
    }

    @Test(description = "listAll returns every registered user")
    public void listAll_returnsAllRegisteredUsers() {
        service.register(new User(1, "Alice", "a@x.com"));
        service.register(new User(2, "Bob",   "b@x.com"));
        service.register(new User(3, "Carol", "c@x.com"));

        List<User> users = service.listAll();
        assertEquals(users.size(), 3, "Should contain three users");
    }

    @Test(description = "removeUser deletes the user from the repository")
    public void removeUser_deletesFromRepository() {
        service.register(new User(1, "Alice", "a@x.com"));
        assertTrue(service.removeUser(1));
        assertTrue(repository.findById(1).isEmpty());
    }

    /**
     * DataProvider — TestNG's equivalent of JUnit's @ParameterizedTest.
     * Each row is a separate test invocation.
     */
    @DataProvider(name = "userSamples")
    public Object[][] userSamples() {
        return new Object[][] {
                {1, "Alice", "alice@example.com"},
                {2, "Bob",   "bob@example.com"},
                {3, "Carol", "carol@example.com"},
        };
    }

    @Test(dataProvider = "userSamples",
          description = "Register multiple users via DataProvider and verify each is retrievable")
    public void registerAndRetrieve_dataDriven(int id, String name, String email) {
        User u = new User(id, name, email);
        service.register(u);
        assertEquals(service.getById(id), u);
    }
}
